package school.sptech;

public interface Vendavel {

    abstract Double getValorVenda();

}
